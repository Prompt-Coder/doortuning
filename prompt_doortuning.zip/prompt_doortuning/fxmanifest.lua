fx_version 'bodacious'
game "gta5"

replace_level_meta 'gta5'

files {
	'gta5.meta',
	'doortuning.ymt',
	'water.xml'
}

escrow_ignore {
  'stream/*.ymt'
}